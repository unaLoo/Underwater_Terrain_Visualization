import { initMap } from "./src/initMap";

initMap();